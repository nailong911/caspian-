

"""Voice call management for client."""
from __future__ import annotations

import asyncio
import logging
import queue
import threading
import time
import uuid
from typing import Any, Callable, Dict, Optional

try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except (ImportError, Exception):
    PYAUDIO_AVAILABLE = False

try:
    import opuslib
    OPUS_AVAILABLE = True
except (ImportError, Exception):
    # opuslib might be installed but the native Opus library might not be available
    OPUS_AVAILABLE = False

from shared.protocol import DEFAULT_VERSION
from shared.protocol.commands import MsgType
from shared.protocol.errors import ProtocolError, StatusCode

logger = logging.getLogger(__name__)


class VoiceCallError(ProtocolError):
    """Voice call specific error."""
    pass


class AudioHandler:
    """Handles audio I/O using PyAudio with optional Opus codec."""

    def __init__(
        self,
        sample_rate: int = 48000,
        channels: int = 1,
        frame_duration: int = 20,  # ms
        use_opus: bool = True,
    ):
        if not PYAUDIO_AVAILABLE:
            raise VoiceCallError(
                StatusCode.INTERNAL_ERROR,
                message="PyAudio not installed. Please install: pip install pyaudio"
            )

        self.sample_rate = sample_rate
        self.channels = channels
        self.frame_duration = frame_duration
        self.frame_size = int(sample_rate * frame_duration / 1000)  # samples per frame
        self.chunk_size = self.frame_size * channels * 2  # bytes (16-bit PCM)

        self.use_opus = use_opus and OPUS_AVAILABLE
        if use_opus and not OPUS_AVAILABLE:
            logger.warning("Opus codec not available, falling back to PCM")
            self.use_opus = False

        self.pyaudio_instance = pyaudio.PyAudio()
        self.input_stream: Optional[pyaudio.Stream] = None
        self.output_stream: Optional[pyaudio.Stream] = None
        self.encoder = None
        self.decoder = None

        if self.use_opus:
            try:
                # Opus application type: 2048 = VOIP
                self.encoder = opuslib.Encoder(sample_rate, channels, opuslib.APPLICATION_VOIP)
                self.decoder = opuslib.Decoder(sample_rate, channels)
                logger.info(f"Opus codec initialized: {sample_rate}Hz, {channels} channel(s)")
            except Exception as e:
                logger.error(f"Failed to initialize Opus codec: {e}, falling back to PCM")
                self.use_opus = False

    def start_input(self) -> None:
        """Start capturing audio from microphone."""
        if self.input_stream:
            return
        try:
            # Test microphone access first
            logger.info("Requesting microphone access...")
            self.input_stream = self.pyaudio_instance.open(
                format=pyaudio.paInt16,
                channels=self.channels,
                rate=self.sample_rate,
                input=True,
                frames_per_buffer=self.frame_size,
            )
            logger.info("Audio input stream started (Microphone access granted)")
        except OSError as e:
            # OSError typically means permission denied or device not found
            raise VoiceCallError(
                StatusCode.INTERNAL_ERROR,
                message=f"无法访问麦克风。请检查：\n1. 麦克风设备是否连接\n2. 是否授予了麦克风权限\n3. 麦克风是否被其他程序占用\n\n详细错误: {e}"
            )
        except Exception as e:
            raise VoiceCallError(
                StatusCode.INTERNAL_ERROR,
                message=f"Failed to start audio input: {e}"
            )

    def start_output(self) -> None:
        """Start audio playback to speaker."""
        if self.output_stream:
            return
        try:
            self.output_stream = self.pyaudio_instance.open(
                format=pyaudio.paInt16,
                channels=self.channels,
                rate=self.sample_rate,
                output=True,
                frames_per_buffer=self.frame_size,
            )
            logger.info("Audio output stream started")
        except Exception as e:
            raise VoiceCallError(
                StatusCode.INTERNAL_ERROR,
                message=f"Failed to start audio output: {e}"
            )

    def read_frame(self) -> Optional[bytes]:
        """Read one audio frame from mic and encode if opus is enabled."""
        if not self.input_stream:
            return None
        try:
            pcm_data = self.input_stream.read(self.frame_size, exception_on_overflow=False)
            if self.use_opus and self.encoder:
                return self.encoder.encode(pcm_data, self.frame_size)
            return pcm_data
        except Exception as e:
            logger.error(f"Failed to read audio frame: {e}")
            return None

    def write_frame(self, data: bytes) -> None:
        """Decode (if opus) and write audio frame to speaker."""
        if not self.output_stream:
            return
        try:
            if self.use_opus and self.decoder:
                pcm_data = self.decoder.decode(data, self.frame_size)
            else:
                pcm_data = data
            self.output_stream.write(pcm_data)
        except Exception as e:
            logger.error(f"Failed to write audio frame: {e}")

    def stop_input(self) -> None:
        """Stop audio capture."""
        if self.input_stream:
            self.input_stream.stop_stream()
            self.input_stream.close()
            self.input_stream = None
            logger.info("Audio input stream stopped")

    def stop_output(self) -> None:
        """Stop audio playback."""
        if self.output_stream:
            self.output_stream.stop_stream()
            self.output_stream.close()
            self.output_stream = None
            logger.info("Audio output stream stopped")

    def cleanup(self) -> None:
        """Release all audio resources."""
        self.stop_input()
        self.stop_output()
        if self.pyaudio_instance:
            self.pyaudio_instance.terminate()
            self.pyaudio_instance = None
        logger.info("Audio handler cleaned up")


class VoiceManager:
    """Manages voice calls: initiate, answer, reject, send/receive audio."""

    def __init__(self, network, session, ui_queue: Optional[queue.Queue] = None):
        self.network = network
        self.session = session
        self.ui_queue = ui_queue

        self.current_call: Optional[Dict[str, Any]] = None
        self.audio_handler: Optional[AudioHandler] = None
        self._send_task: Optional[asyncio.Task] = None
        self._receive_loop_running = False
        self._audio_send_queue: queue.Queue[bytes] = queue.Queue()
        self._audio_thread: Optional[threading.Thread] = None

        # Register event handlers
        self.network.register_handler(MsgType.VOICE_CALL_ACK, self._handle_call_ack)
        self.network.register_handler(MsgType.VOICE_EVENT, self._handle_voice_event)
        self.network.register_handler(MsgType.VOICE_DATA, self._handle_voice_data)

    async def initiate_call(self, target_type: str, target_id: str, call_type: str = "direct") -> Dict[str, Any]:
        """
        Initiate a voice call to user or room.

        Args:
            target_type: "user" or "room"
            target_id: user ID or room ID
            call_type: "direct" for 1-on-1, "group" for conference
        """
        if self.current_call:
            raise VoiceCallError(
                StatusCode.CONFLICT,
                message="Already in a call"
            )

        call_id = uuid.uuid4().hex
        headers = self.session.build_headers()  # 修复：使用session构建headers
        logger.info(f"[VOICE DEBUG] Initiating call, headers={headers}")  # 调试日志
        msg = {
            "id": call_id,
            "type": "request",
            "timestamp": int(time.time()),
            "command": MsgType.VOICE_CALL.value,
            "headers": headers,
            "payload": {
                "call_type": call_type,
                "target": {
                    "type": target_type,
                    "id": target_id
                },
                "codec": "opus" if OPUS_AVAILABLE else "pcm",
                "sample_rate": 48000,
                "channels": 1
            }
        }

        logger.info(f"[VOICE DEBUG] Sending call message: {msg}")  # 调试完整消息
        await self.network.send(msg)
        self.current_call = {
            "call_id": call_id,
            "target_type": target_type,
            "target_id": target_id,
            "call_type": call_type,
            "status": "calling",
            "is_initiator": True,
            "start_time": time.time(),
            "connect_time": None,
        }
        self._notify_ui("status", "正在呼叫...")
        logger.info(f"Initiated call to {target_type}:{target_id}, call_id={call_id}")
        return {"status": 200, "call_id": call_id}

    async def answer_call(self, call_id: str) -> Dict[str, Any]:
        """Answer an incoming call."""
        if not self.current_call or self.current_call.get("call_id") != call_id:
            raise VoiceCallError(StatusCode.NOT_FOUND, message="Call not found")

        msg = {
            "id": uuid.uuid4().hex,
            "type": "request",
            "timestamp": int(time.time()),
            "command": MsgType.VOICE_ANSWER.value,
            "headers": self.session.build_headers(),  # 修复：使用session构建headers
            "payload": {
                "call_id": call_id,
                "codec": "opus" if OPUS_AVAILABLE else "pcm"
            }
        }

        await self.network.send(msg)
        self.current_call["status"] = "connected"
        self._start_audio_streams()
        self._notify_ui("status", "通话已接通")
        logger.info(f"Answered call {call_id}")
        return {"status": 200, "call_id": call_id}

    async def reject_call(self, call_id: str) -> Dict[str, Any]:
        """Reject an incoming call."""
        msg = {
            "id": uuid.uuid4().hex,
            "type": "request",
            "timestamp": int(time.time()),
            "command": MsgType.VOICE_REJECT.value,
            "headers": self.session.build_headers(),  # 修复：使用session构建headers
            "payload": {"call_id": call_id}
        }

        await self.network.send(msg)
        self.current_call = None
        self._notify_ui("status", "已拒绝通话")
        logger.info(f"Rejected call {call_id}")
        return {"status": 200, "call_id": call_id}

    async def end_call(self) -> Dict[str, Any]:
        """End the current call."""
        if not self.current_call:
            return {"status": 200}

        call_id = self.current_call.get("call_id")
        msg = {
            "id": uuid.uuid4().hex,
            "type": "request",
            "timestamp": int(time.time()),
            "command": MsgType.VOICE_END.value,
            "headers": self.session.build_headers(),  # 修复：使用session构建headers
            "payload": {"call_id": call_id}
        }

        await self.network.send(msg)
        self._stop_audio_streams()
        self.current_call = None
        self._notify_ui("status", "通话已结束")
        logger.info(f"Ended call {call_id}")
        return {"status": 200, "call_id": call_id}

    def _start_audio_streams(self) -> None:
        """Start capturing and playing audio."""
        try:
            self.audio_handler = AudioHandler(
                sample_rate=48000,
                channels=1,
                frame_duration=20,
                use_opus=OPUS_AVAILABLE
            )
            self.audio_handler.start_input()
            self.audio_handler.start_output()

            # Start audio capture thread
            self._audio_thread = threading.Thread(
                target=self._audio_capture_loop,
                name="VoiceCapture",
                daemon=True
            )
            self._audio_thread.start()

            # Start audio send task
            self._send_task = asyncio.create_task(self._audio_send_loop(), name="VoiceSend")
            logger.info("Audio streams started")
        except Exception as e:
            logger.error(f"Failed to start audio streams: {e}")
            self._notify_ui("error", f"音频启动失败: {e}")

    def _stop_audio_streams(self) -> None:
        """Stop audio capture and playback."""
        if self._send_task:
            self._send_task.cancel()
            self._send_task = None

        if self._audio_thread:
            # Signal thread to stop (thread will exit on its own)
            self._audio_thread = None

        if self.audio_handler:
            self.audio_handler.cleanup()
            self.audio_handler = None

        logger.info("Audio streams stopped")

    def _audio_capture_loop(self) -> None:
        """Capture audio in background thread and queue for sending."""
        while self.audio_handler and self.current_call and self.current_call.get("status") == "connected":
            try:
                frame = self.audio_handler.read_frame()
                if frame:
                    self._audio_send_queue.put(frame)
                else:
                    time.sleep(0.001)  # Small delay on error
            except Exception as e:
                logger.error(f"Audio capture error: {e}")
                break

    async def _audio_send_loop(self) -> None:
        """Send audio frames from queue to network."""
        while True:
            try:
                # Get frame from queue (non-blocking with timeout)
                try:
                    frame = self._audio_send_queue.get(timeout=0.1)
                except queue.Empty:
                    await asyncio.sleep(0.01)
                    continue

                if self.current_call and self.current_call.get("status") == "connected":
                    call_id = self.current_call.get("call_id")
                    msg = {
                        "id": uuid.uuid4().hex[:8],  # Short ID for efficiency
                        "type": "event",
                        "timestamp": int(time.time()),
                        "command": MsgType.VOICE_DATA.value,
                        "headers": self.session.build_headers(),  # 修复：使用session构建headers
                        "payload": {
                            "call_id": call_id,
                            "data": frame.hex(),  # Encode bytes as hex string
                            "codec": "opus" if OPUS_AVAILABLE else "pcm",
                            "seq": int(time.time() * 1000)  # Sequence number
                        }
                    }
                    await self.network.send(msg)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Audio send error: {e}")

    async def _handle_call_ack(self, message: Dict[str, Any]) -> None:
        """Handle acknowledgment of call initiation."""
        payload = message.get("payload", {})
        status = payload.get("status", 500)

        if status == 200:
            call_id = payload.get("call_id")
            if self.current_call and self.current_call.get("call_id") == call_id:
                self.current_call["status"] = "ringing"
                self._notify_ui("status", "对方响铃中...")
        else:
            error_msg = payload.get("error_message", "Call failed")
            self._notify_ui("error", f"呼叫失败: {error_msg}")
            self.current_call = None

    async def _handle_voice_event(self, message: Dict[str, Any]) -> None:
        """Handle voice call events from server."""
        payload = message.get("payload", {})
        event_type = payload.get("event_type")
        call_id = payload.get("call_id")

        logger.info(f"[VOICE CLIENT] Received voice event: {event_type}, call_id={call_id}, full_payload={payload}")

        if event_type == "incoming":
            # Incoming call
            from_user = payload.get("from_user")
            call_type = payload.get("call_type", "direct")
            target = payload.get("target", {})

            self.current_call = {
                "call_id": call_id,
                "from_user": from_user,
                "call_type": call_type,
                "target_type": target.get("type"),
                "target_id": target.get("id"),
                "status": "incoming",
                "is_initiator": False,
                "start_time": time.time(),
                "connect_time": None,
            }
            self._notify_ui("incoming_call", {
                "call_id": call_id,
                "from_user": from_user,
                "call_type": call_type
            })

        elif event_type == "connected":
            # Call connected
            if self.current_call and self.current_call.get("call_id") == call_id:
                self.current_call["status"] = "connected"
                self.current_call["connect_time"] = time.time()
                self._start_audio_streams()
                self._notify_ui("status", "通话已接通")

        elif event_type in ("ended", "rejected"):
            # Call ended or rejected
            if self.current_call and self.current_call.get("call_id") == call_id:
                self._stop_audio_streams()
                self.current_call = None
                msg = "对方已拒绝" if event_type == "rejected" else "通话已结束"
                self._notify_ui("status", msg)

        elif event_type == "error":
            # Call error
            error_msg = payload.get("message", "Unknown error")
            self._notify_ui("error", f"通话错误: {error_msg}")
            self._stop_audio_streams()
            self.current_call = None

        elif event_type in ("member_joined", "member_left"):
            # Group call member events
            members = payload.get("members", [])
            self._notify_ui("members_changed", members)

    async def _handle_voice_data(self, message: Dict[str, Any]) -> None:
        """Handle incoming voice data."""
        if not self.current_call or self.current_call.get("status") != "connected":
            return

        payload = message.get("payload", {})
        call_id = payload.get("call_id")

        if call_id != self.current_call.get("call_id"):
            return

        data_hex = payload.get("data")
        if data_hex and self.audio_handler:
            try:
                audio_data = bytes.fromhex(data_hex)
                self.audio_handler.write_frame(audio_data)
            except Exception as e:
                logger.error(f"Failed to play audio frame: {e}")

    def _notify_ui(self, event_type: str, data: Any) -> None:
        """Notify UI about voice events."""
        if self.ui_queue:
            self.ui_queue.put(("voice", {"type": event_type, "data": data}))

    def get_current_call(self) -> Optional[Dict[str, Any]]:
        """Get current call information."""
        return self.current_call

    async def cleanup(self) -> None:
        """Cleanup resources."""
        if self.current_call:
            await self.end_call()
        self._stop_audio_streams()
